/*
 * "$Id: ide_visualc.cxx 7586 2010-05-03 20:10:13Z ianmacarthur $"
 */
#define FLTK_DATADIR "C:/FLTK"
#define FLTK_DOCDIR "C:/FLTK/DOC"
#define BORDER_WIDTH 2
#define HAVE_GL 1
#define HAVE_GL_GLU_H 1
#define USE_COLORMAP 1
#define HAVE_XDBE 0
#define USE_XDBE HAVE_XDBE
#define HAVE_OVERLAY 0
#define HAVE_GL_OVERLAY 1
#define WORDS_BIGENDIAN 0
#define U16 unsigned short
#define U32 unsigned
#undef U64
#undef HAVE_VSNPRINTF
#undef HAVE_SNPRINTF
#define HAVE_STRCASECMP 1
#define HAVE_LOCALE_H 1
#define HAVE_LOCALECONV 1
#define HAVE_POLL 0
#define HAVE_LIBPNG
#define HAVE_LIBZ
#define HAVE_LIBJPEG
#define HAVE_PNG_H
#undef HAVE_LIBPNG_PNG_H
#define HAVE_PNG_GET_VALID
#define HAVE_PNG_SET_TRNS_TO_ALPHA
/*
 * End of "$Id: ide_visualc.cxx 7586 2010-05-03 20:10:13Z ianmacarthur $".
 */
